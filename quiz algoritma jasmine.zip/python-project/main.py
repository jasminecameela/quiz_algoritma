# Input nama mahasiswa
print("---Hasil Kelulusan Mahasiswa--")
nama = input("Nama : ")

# Tentukan target berdasarkan nama
if nama.lower() == "andi":
    target = 70
elif nama.lower() == "budi":
    target = 75
elif nama.lower() == "citra":
    target = 80
else:
    target = int(input("Masukkan target nilai: "))

# Input 3 nilai ujian menggunakan perulangan while
percobaan = 0
lulus = False

while percobaan < 3:
    percobaan += 1
    nilai = int(input(f"Nilai {percobaan} : "))
    
    if nilai >= target:
        lulus = True
        break  # Berhenti jika sudah lulus

# Output hasil akhir
print("---Hasil Kelulusan---")
if lulus:
    print(f"{nama} berhasil lulus setelah {percobaan} kali percobaan!")
else:
    print(f"{nama} tidak lulus setelah {percobaan} kali percobaan!")
